public class CarWorkshop {
    public void changeTyre(Car car, Tyre tyre) {
        car.setTyre(tyre);
    }

    public void changeEngine(Car car, Engine engine) {
        car.setEngine(engine);
    }
}
