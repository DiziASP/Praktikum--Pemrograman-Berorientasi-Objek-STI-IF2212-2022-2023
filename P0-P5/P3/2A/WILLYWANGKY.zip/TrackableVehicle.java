public interface TrackableVehicle extends Trackable, Vehicle{
    
}
